NEXUS OS demo package
Not a bootable USB image.
Contains checksums, flash guide, hub smoke frames, PXG sample.
Get full .img from builder releases; verify with SHA256SUMS.
